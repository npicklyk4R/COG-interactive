# Center of gravity and track width — trilingual interactive (EN / FR-CA / ES-US)

No JavaScript — radio buttons + CSS only. Learners switch EN / FR / ES and the three stages (Upright / Leaning / Tipping) inside the graphic.

## 1. Upload
1. On your work GitHub, create a **public** repo (e.g. `rollover-cg-interactive`), or add a folder to an existing Pages-enabled repo.
2. Upload `index.html` (and optionally `cg_interactive_trilingual.html`, an identical copy) to the repo root.
3. Settings → Pages → Source: **Deploy from a branch** → `main` / `(root)` (or `/docs` if you put the files there) → Save.
4. Wait 1–2 minutes; your URL will be `https://YOUR_WORK_ORG.github.io/YOUR_REPO/`.

## 2. EasyGenerator
Page → Embed → HTML/Embed block → paste:

```html
<iframe src="https://YOUR_WORK_ORG.github.io/YOUR_REPO/"
        width="100%" height="740" style="border:0;max-width:1100px"
        title="Center of gravity and track width"
        loading="lazy"></iframe>
```

Replace the placeholder URL with your Pages URL. Preview as a learner and tap each language and stage.
